
## mediasoup-demo Node app using mediasoup-client-aiortc

See [index.ts](./src/index.ts).


