declare const dataConsumers: (state: {}, action: any) => any;
export default dataConsumers;
//# sourceMappingURL=dataConsumers.d.ts.map