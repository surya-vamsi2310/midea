declare const reducers: import("redux").Reducer<import("redux").CombinedState<{
    room: any;
    me: any;
    producers: any;
    dataProducers: any;
    peers: any;
    consumers: any;
    dataConsumers: any;
}>, any>;
export default reducers;
//# sourceMappingURL=index.d.ts.map