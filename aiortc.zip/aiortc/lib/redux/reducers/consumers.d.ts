declare const consumers: (state: {}, action: any) => any;
export default consumers;
//# sourceMappingURL=consumers.d.ts.map