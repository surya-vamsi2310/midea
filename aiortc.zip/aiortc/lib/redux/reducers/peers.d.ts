declare const peers: (state: {}, action: any) => any;
export default peers;
//# sourceMappingURL=peers.d.ts.map