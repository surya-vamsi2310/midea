declare const dataProducers: (state: {}, action: any) => any;
export default dataProducers;
//# sourceMappingURL=dataProducers.d.ts.map